# Free Fire 2018 - Cliente Android

Cliente Android nativo para o servidor Free Fire 2018 emulador, desenvolvido em Kotlin com Android Studio.

## 📋 Requisitos

- **Android Studio** 2022.1 ou superior
- **Android SDK** 21+ (mínimo)
- **Gradle** 7.0+
- **Java** 11+
- **Kotlin** 1.8+

## 🚀 Instalação e Compilação

### 1. Clonar o Repositório

```bash
git clone <repository-url> freefire-android
cd freefire-android
```

### 2. Abrir no Android Studio

1. Abra Android Studio
2. File → Open → Selecione a pasta `freefire-android`
3. Aguarde o Gradle sincronizar

### 3. Compilar o APK

#### Opção A: Debug (Desenvolvimento)

```bash
./gradlew assembleDebug
```

O APK será criado em: `app/build/outputs/apk/debug/app-debug.apk`

#### Opção B: Release (Produção)

```bash
./gradlew assembleRelease
```

O APK será criado em: `app/build/outputs/apk/release/app-release.apk`

### 4. Instalar no Dispositivo

```bash
# Debug
adb install app/build/outputs/apk/debug/app-debug.apk

# Release
adb install app/build/outputs/apk/release/app-release.apk
```

## ⚙️ Configuração

### Configurar Servidor

Edite o arquivo `src/main/java/com/freefire/mobile/config/ServerConfig.kt`:

```kotlin
const val SERVER_HOST = "192.168.1.100"  // IP do seu servidor
const val SERVER_PORT = 8001
const val SERVER_UDP_PORT = 9001
```

### Configurar Assinatura (Release)

1. Criar keystore:
```bash
keytool -genkey -v -keystore release.keystore -keyalg RSA -keysize 2048 -validity 10000 -alias freefire
```

2. Editar `build.gradle`:
```gradle
signingConfigs {
    release {
        storeFile file("release.keystore")
        storePassword "sua_senha"
        keyAlias "freefire"
        keyPassword "sua_senha"
    }
}
```

## 📁 Estrutura do Projeto

```
freefire-android/
├── src/main/
│   ├── java/com/freefire/mobile/
│   │   ├── config/
│   │   │   └── ServerConfig.kt
│   │   ├── data/
│   │   │   └── models/
│   │   │       └── Player.kt
│   │   ├── network/
│   │   │   ├── api/
│   │   │   │   └── GameApi.kt
│   │   │   └── NetworkManager.kt
│   │   └── ui/
│   │       ├── MainActivity.kt
│   │       ├── LoginActivity.kt
│   │       ├── LobbyActivity.kt
│   │       ├── GameActivity.kt
│   │       └── SettingsActivity.kt
│   └── res/
│       ├── layout/
│       ├── values/
│       └── drawable/
├── build.gradle
├── settings.gradle
└── README.md
```

## 🎮 Funcionalidades

### Implementadas ✅
- Login com UID e Nickname
- Conexão com servidor via Retrofit
- Autenticação com JWT
- Gerenciamento de sessão
- Interface de login moderna

### Em Desenvolvimento 🚧
- Lobby com lista de salas
- Criar/Entrar em salas
- Jogo 3D com sincronização
- Chat em tempo real
- Estatísticas e ranking
- Configurações de gráficos

### Planejadas 📋
- Suporte a múltiplas regiões
- Sistema de amigos
- Clã/Guilda
- Loja de itens
- Eventos e desafios
- Replay de partidas

## 🔧 Desenvolvimento

### Adicionar Nova Atividade

1. Criar arquivo em `src/main/java/com/freefire/mobile/ui/NovaActivity.kt`
2. Criar layout em `res/layout/activity_nova.xml`
3. Registrar em `AndroidManifest.xml`
4. Navegar usando Intent

### Adicionar Novo Endpoint

1. Adicionar método em `network/api/GameApi.kt`
2. Criar modelos de request/response
3. Usar em ViewModel ou Activity

### Debugging

```bash
# Ver logs
adb logcat | grep "FreeFire"

# Conectar debugger
adb forward tcp:5005 tcp:5005
```

## 📊 Requisitos de Rede

| Protocolo | Porta | Tipo |
|-----------|-------|------|
| HTTP/REST | 8001  | TCP  |
| WebSocket | 8001  | TCP  |
| Jogo      | 9001  | UDP  |

## 🔐 Segurança

- ✅ HTTPS em produção (configurar em ServerConfig)
- ✅ Validação de token JWT
- ✅ Proteção contra XSS
- ✅ Rate limiting recomendado
- ⚠️ Não armazenar senhas em texto plano

## 📱 Compatibilidade

- **Mínimo:** Android 5.0 (API 21)
- **Recomendado:** Android 10+ (API 29+)
- **Orientação:** Portrait (Login/Lobby), Landscape (Jogo)

## 🐛 Troubleshooting

### Erro: "Connection refused"
- Verificar se o servidor está rodando
- Verificar IP e porta em ServerConfig
- Verificar firewall

### Erro: "SSL Certificate Problem"
- Em debug, usar `usesCleartextTraffic="true"` em AndroidManifest.xml
- Em produção, usar HTTPS e certificado válido

### Erro: "Out of Memory"
- Aumentar heap size em build.gradle:
```gradle
android {
    dexOptions {
        javaMaxHeapSize "2g"
    }
}
```

## 📚 Documentação

- [Android Developer Guide](https://developer.android.com/)
- [Retrofit Documentation](https://square.github.io/retrofit/)
- [Kotlin Coroutines](https://kotlinlang.org/docs/coroutines-overview.html)
- [Material Design](https://material.io/design)

## 📝 Licença

Este projeto é fornecido como-é para fins educacionais.

## 🤝 Contribuindo

Contribuições são bem-vindas! Por favor:

1. Fork o repositório
2. Crie uma branch para sua feature
3. Commit suas mudanças
4. Push para a branch
5. Abra um Pull Request

## 📞 Suporte

Para dúvidas ou problemas:

1. Verificar logs: `adb logcat`
2. Consultar documentação
3. Abrir issue no repositório

---

**Desenvolvido com fins educacionais para análise de arquitetura de servidor de jogos.**
