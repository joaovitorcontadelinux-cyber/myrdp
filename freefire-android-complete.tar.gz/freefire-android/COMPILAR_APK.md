# Guia de Compilação do APK - Free Fire 2018 Android

Este guia explica como compilar o cliente Android para Free Fire 2018.

## 📋 Pré-requisitos

- **Android Studio** 2022.1 ou superior
- **Android SDK** (mínimo API 21)
- **Java Development Kit (JDK)** 11 ou superior
- **Gradle** (incluído no Android Studio)
- **Git** (opcional, para clonar repositório)

## 🚀 Passo 1: Preparar Ambiente

### Windows/Mac/Linux

1. Baixar e instalar [Android Studio](https://developer.android.com/studio)
2. Durante a instalação, selecionar:
   - Android SDK
   - Android Virtual Device (AVD)
   - Android SDK Build-Tools

3. Abrir Android Studio e ir para:
   - **Tools** → **SDK Manager**
   - Instalar SDK Platform 33 (ou superior)
   - Instalar Build-Tools 33.0.0 (ou superior)

## 🔧 Passo 2: Abrir Projeto

1. Clonar ou baixar o projeto:
```bash
git clone <repository-url> freefire-android
cd freefire-android
```

2. Abrir no Android Studio:
   - **File** → **Open**
   - Selecionar pasta `freefire-android`
   - Aguardar sincronização do Gradle

## ⚙️ Passo 3: Configurar Servidor

Editar arquivo: `src/main/java/com/freefire/mobile/config/ServerConfig.kt`

```kotlin
const val SERVER_HOST = "192.168.1.100"  // Seu IP do servidor
const val SERVER_PORT = 8001
```

## 🔨 Passo 4: Compilar APK

### Opção A: Usando Android Studio (Recomendado)

1. Ir para **Build** → **Build Bundle(s) / APK(s)** → **Build APK(s)**
2. Aguardar compilação
3. Quando terminar, clicar em **Locate** para abrir pasta

O APK será salvo em:
```
app/build/outputs/apk/debug/app-debug.apk
```

### Opção B: Usando Linha de Comando

#### Debug (Desenvolvimento)

```bash
cd /home/ubuntu/freefire-android
./gradlew assembleDebug
```

APK em: `app/build/outputs/apk/debug/app-debug.apk`

#### Release (Produção)

```bash
./gradlew assembleRelease
```

APK em: `app/build/outputs/apk/release/app-release.apk`

## 📱 Passo 5: Instalar no Dispositivo

### Opção A: Via USB

1. Conectar dispositivo Android via USB
2. Ativar "Modo de Desenvolvedor" no celular:
   - Ir para **Configurações** → **Sobre o Telefone**
   - Tocar 7 vezes em "Número da Compilação"
   - Voltar para **Configurações** → **Opções de Desenvolvedor**
   - Ativar "Depuração USB"

3. No Android Studio:
   - Clicar em **Run** → **Run 'app'**
   - Selecionar dispositivo
   - Aguardar instalação

### Opção B: Via ADB (Linha de Comando)

```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

### Opção C: Arquivo APK Manual

1. Transferir arquivo APK para celular
2. Abrir gerenciador de arquivos
3. Tocar no APK
4. Confirmar instalação

## 🔐 Passo 6: Assinar APK (Release)

Para distribuir o APK, é necessário assiná-lo:

### 1. Criar Keystore

```bash
keytool -genkey -v -keystore release.keystore -keyalg RSA -keysize 2048 -validity 10000 -alias freefire
```

Responder as perguntas:
- **Senha do keystore:** (criar uma)
- **Nome:** Seu Nome
- **Organização:** Sua Organização
- **País:** BR (ou seu país)

### 2. Configurar build.gradle

Editar `app/build.gradle`:

```gradle
android {
    ...
    signingConfigs {
        release {
            storeFile file("release.keystore")
            storePassword "sua_senha_do_keystore"
            keyAlias "freefire"
            keyPassword "sua_senha_da_chave"
        }
    }
    
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
}
```

### 3. Compilar Release Assinado

```bash
./gradlew assembleRelease
```

APK assinado em: `app/build/outputs/apk/release/app-release.apk`

## 🧪 Passo 7: Testar

### No Emulador

1. Abrir Android Studio
2. **Tools** → **AVD Manager**
3. Criar novo emulador (Pixel 4, API 33)
4. Iniciar emulador
5. **Run** → **Run 'app'**

### No Dispositivo Real

1. Conectar dispositivo
2. **Run** → **Run 'app'**
3. Selecionar dispositivo
4. Aguardar instalação

## 🐛 Troubleshooting

### Erro: "Gradle sync failed"

```bash
cd freefire-android
./gradlew clean
./gradlew build
```

### Erro: "SDK not found"

1. Abrir **Tools** → **SDK Manager**
2. Instalar SDK Platform 33
3. Instalar Build-Tools 33.0.0

### Erro: "Connection refused"

Verificar:
- Servidor está rodando?
- IP do servidor está correto em `ServerConfig.kt`?
- Firewall permite conexão?

### Erro: "Out of memory"

Aumentar heap size em `gradle.properties`:

```properties
org.gradle.jvmargs=-Xmx2048m
```

## 📊 Tamanho do APK

- **Debug:** ~50-80 MB
- **Release (otimizado):** ~30-50 MB

## 🔒 Segurança

### Para Produção

1. Usar HTTPS em `ServerConfig.kt`
2. Assinar APK com certificado válido
3. Remover logs de debug
4. Ativar ProGuard/R8

## 📦 Distribuição

### Opções

1. **Google Play Store** (requer conta de desenvolvedor)
2. **APK direto** (via email, WhatsApp, etc)
3. **Repositório privado** (GitHub, GitLab)

## 📞 Suporte

Se encontrar problemas:

1. Verificar logs: `adb logcat | grep FreeFire`
2. Consultar documentação Android
3. Abrir issue no repositório

---

**Seu APK está pronto para compilar! 📱**
