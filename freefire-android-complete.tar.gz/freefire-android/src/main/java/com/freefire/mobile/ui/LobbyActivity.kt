package com.freefire.mobile.ui

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.freefire.mobile.R
import com.freefire.mobile.databinding.ActivityLobbyBinding
import com.freefire.mobile.data.models.Player
import com.freefire.mobile.network.NetworkManager
import com.freefire.mobile.network.api.RoomInfo
import kotlinx.coroutines.launch

class LobbyActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityLobbyBinding
    private lateinit var currentPlayer: Player
    private var rooms: MutableList<RoomInfo> = mutableListOf()
    private val TAG = "LobbyActivity"
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        binding = ActivityLobbyBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        // Recuperar jogador do intent
        currentPlayer = intent.getSerializableExtra("player") as? Player
            ?: run {
                Toast.makeText(this, "Erro ao carregar jogador", Toast.LENGTH_SHORT).show()
                finish()
                return
            }
        
        setupUI()
        loadRooms()
    }
    
    private fun setupUI() {
        binding.apply {
            // Mostrar informações do jogador
            playerNameText.text = currentPlayer.nickname
            playerLevelText.text = "Nível ${currentPlayer.level}"
            playerKDText.text = "K/D: ${String.format("%.2f", currentPlayer.getKDRatio())}"
            
            // Configurar RecyclerView de salas
            roomsRecyclerView.layoutManager = LinearLayoutManager(this@LobbyActivity)
            
            // Botão para criar sala
            createRoomButton.setOnClickListener {
                showCreateRoomDialog()
            }
            
            // Botão para atualizar salas
            refreshButton.setOnClickListener {
                loadRooms()
            }
            
            // Botão de configurações
            settingsButton.setOnClickListener {
                startActivity(Intent(this@LobbyActivity, SettingsActivity::class.java))
            }
            
            // Botão de logout
            logoutButton.setOnClickListener {
                performLogout()
            }
        }
    }
    
    private fun loadRooms() {
        showLoading(true)
        
        lifecycleScope.launch {
            try {
                val gameApi = NetworkManager.getGameApi()
                val authToken = NetworkManager.getAuthorizationHeader()
                
                val response = gameApi.getRooms(authToken)
                
                if (response.isSuccessful && response.body() != null) {
                    rooms = response.body()!!.toMutableList()
                    updateRoomsList()
                    Log.d(TAG, "Salas carregadas: ${rooms.size}")
                } else {
                    showError("Erro ao carregar salas: ${response.code()}")
                }
                
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao carregar salas", e)
                showError("Erro de conexão: ${e.message}")
            } finally {
                showLoading(false)
            }
        }
    }
    
    private fun updateRoomsList() {
        // Criar adapter e atualizar RecyclerView
        // TODO: Implementar RoomAdapter
        binding.roomsRecyclerView.adapter = RoomAdapter(rooms) { room ->
            joinRoom(room)
        }
    }
    
    private fun joinRoom(room: RoomInfo) {
        showLoading(true)
        
        lifecycleScope.launch {
            try {
                val gameApi = NetworkManager.getGameApi()
                val authToken = NetworkManager.getAuthorizationHeader()
                
                val response = gameApi.joinRoom(authToken, room.id)
                
                if (response.isSuccessful && response.body() != null) {
                    Toast.makeText(this@LobbyActivity, "Entrou na sala!", Toast.LENGTH_SHORT).show()
                    
                    // Navegar para GameActivity
                    val intent = Intent(this@LobbyActivity, GameActivity::class.java)
                    intent.putExtra("room", room)
                    intent.putExtra("player", currentPlayer)
                    startActivity(intent)
                } else {
                    showError("Erro ao entrar na sala")
                }
                
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao entrar na sala", e)
                showError("Erro: ${e.message}")
            } finally {
                showLoading(false)
            }
        }
    }
    
    private fun showCreateRoomDialog() {
        // TODO: Implementar dialog para criar sala
        Toast.makeText(this, "Criar sala (em desenvolvimento)", Toast.LENGTH_SHORT).show()
    }
    
    private fun performLogout() {
        showLoading(true)
        
        lifecycleScope.launch {
            try {
                val gameApi = NetworkManager.getGameApi()
                val authToken = NetworkManager.getAuthorizationHeader()
                
                val response = gameApi.logout(authToken)
                
                if (response.isSuccessful) {
                    NetworkManager.clearAuthToken()
                    
                    val intent = Intent(this@LobbyActivity, LoginActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    startActivity(intent)
                    finish()
                }
                
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao fazer logout", e)
            } finally {
                showLoading(false)
            }
        }
    }
    
    private fun showLoading(show: Boolean) {
        binding.progressBar.visibility = if (show) android.view.View.VISIBLE else android.view.View.GONE
    }
    
    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        Log.e(TAG, message)
    }
}

// Adapter para RecyclerView de salas
class RoomAdapter(
    private val rooms: List<RoomInfo>,
    private val onRoomClick: (RoomInfo) -> Unit
) : RecyclerView.Adapter<RoomAdapter.RoomViewHolder>() {
    
    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): RoomViewHolder {
        val view = android.widget.LinearLayout(parent.context).apply {
            layoutParams = android.view.ViewGroup.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT
            )
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
        }
        return RoomViewHolder(view, onRoomClick)
    }
    
    override fun onBindViewHolder(holder: RoomViewHolder, position: Int) {
        holder.bind(rooms[position])
    }
    
    override fun getItemCount() = rooms.size
    
    class RoomViewHolder(
        private val itemView: android.view.View,
        private val onRoomClick: (RoomInfo) -> Unit
    ) : RecyclerView.ViewHolder(itemView) {
        
        fun bind(room: RoomInfo) {
            val layout = itemView as android.widget.LinearLayout
            layout.removeAllViews()
            
            // Nome da sala
            val nameText = android.widget.TextView(itemView.context).apply {
                text = room.name
                textSize = 16f
                setTextColor(android.graphics.Color.WHITE)
            }
            layout.addView(nameText)
            
            // Informações
            val infoText = android.widget.TextView(itemView.context).apply {
                text = "${room.currentPlayers}/${room.maxPlayers} | ${room.map}"
                textSize = 12f
                setTextColor(android.graphics.Color.GRAY)
            }
            layout.addView(infoText)
            
            // Click listener
            itemView.setOnClickListener {
                onRoomClick(room)
            }
        }
    }
}
