package com.freefire.mobile.ui

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.freefire.mobile.R
import com.freefire.mobile.databinding.ActivityMainBinding
import com.freefire.mobile.network.NetworkManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityMainBinding
    private val TAG = "MainActivity"
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Inicializar View Binding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        // Inicializar NetworkManager
        try {
            NetworkManager.initialize(this)
            Log.d(TAG, "NetworkManager inicializado")
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao inicializar NetworkManager", e)
            showError("Erro de conexão: ${e.message}")
            return
        }
        
        // Configurar UI
        setupUI()
        
        // Mostrar splash screen por 2 segundos
        lifecycleScope.launch {
            delay(2000)
            navigateToLogin()
        }
    }
    
    private fun setupUI() {
        // Configurar elementos da UI
        binding.apply {
            // Adicionar listeners se necessário
        }
    }
    
    private fun navigateToLogin() {
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish()
    }
    
    private fun showError(message: String) {
        Log.e(TAG, message)
        // Mostrar erro em um Toast ou Dialog
    }
}
