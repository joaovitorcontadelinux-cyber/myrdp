package com.freefire.mobile.config

object ServerConfig {
    // Configuração do Servidor
    const val SERVER_HOST = "localhost"  // Mude para o IP do seu servidor
    const val SERVER_PORT = 8001
    const val SERVER_UDP_PORT = 9001
    
    // URLs da API
    const val API_BASE_URL = "http://$SERVER_HOST:$SERVER_PORT/api/"
    const val WEBSOCKET_URL = "ws://$SERVER_HOST:$SERVER_PORT/ws"
    
    // Endpoints
    const val ENDPOINT_LOGIN = "auth/login"
    const val ENDPOINT_VERIFY = "auth/verify"
    const val ENDPOINT_ROOMS = "rooms"
    const val ENDPOINT_JOIN_ROOM = "rooms/{id}/join"
    const val ENDPOINT_PLAYER_STATS = "player/stats"
    const val ENDPOINT_LOGOUT = "auth/logout"
    
    // Configurações de Jogo
    const val GAME_VERSION = "1.0.0"
    const val GAME_REGION = "BR"
    const val MAX_PLAYERS_PER_ROOM = 50
    
    // Timeouts
    const val CONNECTION_TIMEOUT = 30000L  // 30 segundos
    const val READ_TIMEOUT = 30000L
    const val WRITE_TIMEOUT = 30000L
    
    // Configurações de Rede
    const val PACKET_SIZE = 1024
    const val BUFFER_SIZE = 65536
    
    // Configurações de Jogo
    const val TICK_RATE = 20  // 20 ticks por segundo
    const val POSITION_UPDATE_INTERVAL = 2  // Atualizar posição a cada 2 ticks
    
    // Configurações de Mapa
    const val MAP_WIDTH = 500
    const val MAP_HEIGHT = 500
    const val MAP_NAME = "Bermuda"
    
    // Configurações de Câmera
    const val CAMERA_FOV = 75f
    const val CAMERA_NEAR = 0.1f
    const val CAMERA_FAR = 1000f
    
    // Configurações de Física
    const val GRAVITY = 9.81f
    const val PLAYER_SPEED = 5f
    const val JUMP_FORCE = 5f
    
    // Configurações de Áudio
    const val MASTER_VOLUME = 1.0f
    const val MUSIC_VOLUME = 0.7f
    const val SFX_VOLUME = 0.8f
    const val VOICE_VOLUME = 0.9f
    
    // Configurações de Gráficos
    const val GRAPHICS_QUALITY = "HIGH"  // LOW, MEDIUM, HIGH, ULTRA
    const val SHADOW_QUALITY = "MEDIUM"
    const val TEXTURE_QUALITY = "HIGH"
    const val ANTI_ALIASING = true
    
    // Configurações de Controle
    const val SENSITIVITY_X = 1.0f
    const val SENSITIVITY_Y = 1.0f
    const val INVERT_Y = false
    
    // Configurações de Debug
    const val DEBUG_MODE = true
    const val LOG_NETWORK_PACKETS = false
    const val SHOW_FPS = true
    const val SHOW_PING = true
}
