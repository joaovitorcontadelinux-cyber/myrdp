package com.freefire.mobile.network

import android.content.Context
import android.util.Log
import com.freefire.mobile.config.ServerConfig
import com.freefire.mobile.network.api.GameApi
import com.google.gson.GsonBuilder
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object NetworkManager {
    private const val TAG = "NetworkManager"
    
    private lateinit var retrofit: Retrofit
    private lateinit var gameApi: GameApi
    private lateinit var okHttpClient: OkHttpClient
    
    private var authToken: String? = null
    
    fun initialize(context: Context) {
        try {
            // Configurar logging
            val loggingInterceptor = HttpLoggingInterceptor { message ->
                Log.d(TAG, message)
            }.apply {
                level = if (ServerConfig.DEBUG_MODE) {
                    HttpLoggingInterceptor.Level.BODY
                } else {
                    HttpLoggingInterceptor.Level.BASIC
                }
            }
            
            // Configurar OkHttpClient
            okHttpClient = OkHttpClient.Builder()
                .addInterceptor(loggingInterceptor)
                .connectTimeout(ServerConfig.CONNECTION_TIMEOUT, TimeUnit.MILLISECONDS)
                .readTimeout(ServerConfig.READ_TIMEOUT, TimeUnit.MILLISECONDS)
                .writeTimeout(ServerConfig.WRITE_TIMEOUT, TimeUnit.MILLISECONDS)
                .build()
            
            // Configurar Gson
            val gson = GsonBuilder()
                .setLenient()
                .create()
            
            // Configurar Retrofit
            retrofit = Retrofit.Builder()
                .baseUrl(ServerConfig.API_BASE_URL)
                .client(okHttpClient)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build()
            
            // Criar instância da API
            gameApi = retrofit.create(GameApi::class.java)
            
            Log.d(TAG, "NetworkManager inicializado com sucesso")
            Log.d(TAG, "Base URL: ${ServerConfig.API_BASE_URL}")
            
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao inicializar NetworkManager", e)
            throw RuntimeException("Falha ao inicializar NetworkManager", e)
        }
    }
    
    fun getGameApi(): GameApi {
        if (!::gameApi.isInitialized) {
            throw RuntimeException("NetworkManager não foi inicializado. Chame initialize() primeiro.")
        }
        return gameApi
    }
    
    fun setAuthToken(token: String) {
        authToken = token
        Log.d(TAG, "Token de autenticação definido")
    }
    
    fun getAuthToken(): String? = authToken
    
    fun clearAuthToken() {
        authToken = null
        Log.d(TAG, "Token de autenticação removido")
    }
    
    fun isAuthenticated(): Boolean = authToken != null
    
    fun getAuthorizationHeader(): String {
        return "Bearer ${authToken ?: ""}"
    }
    
    fun setServerHost(host: String) {
        Log.d(TAG, "Alterando servidor para: $host")
        // Nota: Em produção, você precisaria recriar o Retrofit com a nova URL
    }
    
    fun getServerUrl(): String {
        return "${ServerConfig.SERVER_HOST}:${ServerConfig.SERVER_PORT}"
    }
    
    fun getWebSocketUrl(): String {
        return ServerConfig.WEBSOCKET_URL
    }
}
