package com.freefire.mobile.ui

import android.os.Bundle
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.freefire.mobile.R
import com.freefire.mobile.databinding.ActivitySettingsBinding
import com.freefire.mobile.config.ServerConfig

class SettingsActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivitySettingsBinding
    private val TAG = "SettingsActivity"
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setupUI()
    }
    
    private fun setupUI() {
        binding.apply {
            // Abas de configuração
            tabLayout.addOnTabSelectedListener(object : com.google.android.material.tabs.TabLayout.OnTabSelectedListener {
                override fun onTabSelected(tab: com.google.android.material.tabs.TabLayout.Tab?) {
                    when (tab?.position) {
                        0 -> showGraphicsSettings()
                        1 -> showAudioSettings()
                        2 -> showControlSettings()
                        3 -> showNetworkSettings()
                        4 -> showAbout()
                    }
                }
                
                override fun onTabUnselected(tab: com.google.android.material.tabs.TabLayout.Tab?) {}
                override fun onTabReselected(tab: com.google.android.material.tabs.TabLayout.Tab?) {}
            })
            
            // Botão de salvar
            saveButton.setOnClickListener {
                saveSettings()
            }
            
            // Botão de voltar
            backButton.setOnClickListener {
                finish()
            }
        }
    }
    
    private fun showGraphicsSettings() {
        binding.apply {
            settingsTitle.text = "Configurações de Gráficos"
            
            // Qualidade de gráficos
            qualitySeekBar.progress = 75
            qualityText.text = "Qualidade: ${getQualityLabel(75)}"
            qualitySeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    qualityText.text = "Qualidade: ${getQualityLabel(progress)}"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
            
            // Sombras
            shadowSwitch.isChecked = true
            shadowSwitch.setOnCheckedChangeListener { _, isChecked ->
                shadowText.text = if (isChecked) "Sombras: Ativadas" else "Sombras: Desativadas"
            }
            
            // Anti-aliasing
            aaSwitch.isChecked = true
            aaSwitch.setOnCheckedChangeListener { _, isChecked ->
                aaText.text = if (isChecked) "Anti-aliasing: Ativado" else "Anti-aliasing: Desativado"
            }
        }
    }
    
    private fun showAudioSettings() {
        binding.apply {
            settingsTitle.text = "Configurações de Áudio"
            
            // Volume Master
            masterVolumeSeekBar.progress = 100
            masterVolumeText.text = "Volume Master: 100%"
            masterVolumeSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    masterVolumeText.text = "Volume Master: $progress%"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
            
            // Volume de Música
            musicVolumeSeekBar.progress = 70
            musicVolumeText.text = "Volume Música: 70%"
            musicVolumeSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    musicVolumeText.text = "Volume Música: $progress%"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
            
            // Volume de Efeitos
            sfxVolumeSeekBar.progress = 80
            sfxVolumeText.text = "Volume Efeitos: 80%"
            sfxVolumeSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    sfxVolumeText.text = "Volume Efeitos: $progress%"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
    }
    
    private fun showControlSettings() {
        binding.apply {
            settingsTitle.text = "Configurações de Controle"
            
            // Sensibilidade X
            sensitivityXSeekBar.progress = 50
            sensitivityXText.text = "Sensibilidade X: 1.0"
            sensitivityXSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val value = (progress / 50f)
                    sensitivityXText.text = "Sensibilidade X: ${"%.1f".format(value)}"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
            
            // Sensibilidade Y
            sensitivityYSeekBar.progress = 50
            sensitivityYText.text = "Sensibilidade Y: 1.0"
            sensitivityYSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val value = (progress / 50f)
                    sensitivityYText.text = "Sensibilidade Y: ${"%.1f".format(value)}"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
            
            // Inverter Y
            invertYSwitch.isChecked = false
            invertYSwitch.setOnCheckedChangeListener { _, isChecked ->
                invertYText.text = if (isChecked) "Inverter Y: Ativado" else "Inverter Y: Desativado"
            }
        }
    }
    
    private fun showNetworkSettings() {
        binding.apply {
            settingsTitle.text = "Configurações de Rede"
            
            // Servidor
            serverText.text = "Servidor: ${ServerConfig.SERVER_HOST}:${ServerConfig.SERVER_PORT}"
            
            // Região
            regionText.text = "Região: ${ServerConfig.GAME_REGION}"
            
            // Versão do Jogo
            versionText.text = "Versão: ${ServerConfig.GAME_VERSION}"
        }
    }
    
    private fun showAbout() {
        binding.apply {
            settingsTitle.text = "Sobre"
            
            // Informações
            aboutText.text = """
                Free Fire 2018 Server Emulator
                Versão: ${ServerConfig.GAME_VERSION}
                
                Cliente Android para servidor Free Fire 2018
                
                Desenvolvido com fins educacionais
                
                © 2024 - Todos os direitos reservados
            """.trimIndent()
        }
    }
    
    private fun saveSettings() {
        Toast.makeText(this, "Configurações salvas!", Toast.LENGTH_SHORT).show()
        // TODO: Salvar configurações em SharedPreferences
    }
    
    private fun getQualityLabel(progress: Int): String {
        return when {
            progress < 25 -> "Baixa"
            progress < 50 -> "Média"
            progress < 75 -> "Alta"
            else -> "Ultra"
        }
    }
}
