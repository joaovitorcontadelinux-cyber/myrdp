package com.freefire.mobile.data.models

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class Player(
    @SerializedName("uid")
    val uid: Long,
    
    @SerializedName("nickname")
    val nickname: String,
    
    @SerializedName("level")
    val level: Int = 1,
    
    @SerializedName("experience")
    val experience: Long = 0,
    
    @SerializedName("kills")
    val kills: Int = 0,
    
    @SerializedName("deaths")
    val deaths: Int = 0,
    
    @SerializedName("wins")
    val wins: Int = 0,
    
    @SerializedName("matches")
    val matches: Int = 0,
    
    @SerializedName("headshots")
    val headshots: Int = 0,
    
    @SerializedName("health")
    var health: Int = 100,
    
    @SerializedName("armor")
    var armor: Int = 0,
    
    @SerializedName("position")
    var position: Vector3 = Vector3(0f, 0f, 0f),
    
    @SerializedName("rotation")
    var rotation: Vector3 = Vector3(0f, 0f, 0f),
    
    @SerializedName("weapon")
    var weapon: String = "AK47",
    
    @SerializedName("ammo")
    var ammo: Int = 120,
    
    @SerializedName("region")
    val region: String = "BR",
    
    @SerializedName("status")
    var status: String = "LOBBY",  // LOBBY, LOADING, INGAME, DEAD
    
    @SerializedName("last_seen")
    val lastSeen: Long = System.currentTimeMillis(),
    
    @SerializedName("created_at")
    val createdAt: Long = System.currentTimeMillis()
) : Serializable {
    
    fun isAlive(): Boolean = health > 0
    
    fun takeDamage(damage: Int) {
        val actualDamage = if (armor > 0) {
            val reducedDamage = (damage * 0.75).toInt()
            armor -= reducedDamage / 2
            reducedDamage
        } else {
            damage
        }
        health -= actualDamage
        if (health < 0) health = 0
    }
    
    fun heal(amount: Int) {
        health += amount
        if (health > 100) health = 100
    }
    
    fun getKDRatio(): Float {
        return if (deaths == 0) kills.toFloat() else kills.toFloat() / deaths
    }
    
    fun getWinRate(): Float {
        return if (matches == 0) 0f else (wins.toFloat() / matches) * 100
    }
}

data class Vector3(
    @SerializedName("x")
    val x: Float = 0f,
    
    @SerializedName("y")
    val y: Float = 0f,
    
    @SerializedName("z")
    val z: Float = 0f
) : Serializable {
    
    fun distance(other: Vector3): Float {
        val dx = x - other.x
        val dy = y - other.y
        val dz = z - other.z
        return kotlin.math.sqrt((dx * dx + dy * dy + dz * dz).toDouble()).toFloat()
    }
    
    fun length(): Float {
        return kotlin.math.sqrt((x * x + y * y + z * z).toDouble()).toFloat()
    }
}

data class PlayerStats(
    @SerializedName("uid")
    val uid: Long,
    
    @SerializedName("nickname")
    val nickname: String,
    
    @SerializedName("level")
    val level: Int,
    
    @SerializedName("experience")
    val experience: Long,
    
    @SerializedName("kills")
    val kills: Int,
    
    @SerializedName("deaths")
    val deaths: Int,
    
    @SerializedName("wins")
    val wins: Int,
    
    @SerializedName("matches")
    val matches: Int,
    
    @SerializedName("headshots")
    val headshots: Int,
    
    @SerializedName("rank")
    val rank: String,
    
    @SerializedName("rank_points")
    val rankPoints: Int
) : Serializable
