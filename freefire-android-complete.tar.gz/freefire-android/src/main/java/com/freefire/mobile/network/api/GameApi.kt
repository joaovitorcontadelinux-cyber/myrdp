package com.freefire.mobile.network.api

import com.freefire.mobile.data.models.Player
import com.freefire.mobile.data.models.PlayerStats
import retrofit2.Response
import retrofit2.http.*

interface GameApi {
    
    // ========== AUTENTICAÇÃO ==========
    
    @POST("auth/login")
    suspend fun login(
        @Body request: LoginRequest
    ): Response<LoginResponse>
    
    @POST("auth/verify")
    suspend fun verifyToken(
        @Header("Authorization") token: String
    ): Response<VerifyResponse>
    
    @POST("auth/logout")
    suspend fun logout(
        @Header("Authorization") token: String
    ): Response<LogoutResponse>
    
    // ========== JOGADOR ==========
    
    @GET("player/stats")
    suspend fun getPlayerStats(
        @Header("Authorization") token: String,
        @Query("uid") uid: Long
    ): Response<PlayerStats>
    
    @GET("player/profile")
    suspend fun getPlayerProfile(
        @Header("Authorization") token: String,
        @Query("uid") uid: Long
    ): Response<Player>
    
    @PUT("player/profile")
    suspend fun updatePlayerProfile(
        @Header("Authorization") token: String,
        @Body player: Player
    ): Response<Player>
    
    // ========== SALAS ==========
    
    @GET("rooms")
    suspend fun getRooms(
        @Header("Authorization") token: String
    ): Response<List<RoomInfo>>
    
    @GET("rooms/{id}")
    suspend fun getRoomInfo(
        @Header("Authorization") token: String,
        @Path("id") roomId: String
    ): Response<RoomInfo>
    
    @POST("rooms")
    suspend fun createRoom(
        @Header("Authorization") token: String,
        @Body request: CreateRoomRequest
    ): Response<RoomInfo>
    
    @POST("rooms/{id}/join")
    suspend fun joinRoom(
        @Header("Authorization") token: String,
        @Path("id") roomId: String
    ): Response<JoinRoomResponse>
    
    @POST("rooms/{id}/leave")
    suspend fun leaveRoom(
        @Header("Authorization") token: String,
        @Path("id") roomId: String
    ): Response<LeaveRoomResponse>
    
    // ========== PARTIDAS ==========
    
    @POST("matches/start")
    suspend fun startMatch(
        @Header("Authorization") token: String,
        @Body request: StartMatchRequest
    ): Response<MatchInfo>
    
    @POST("matches/{id}/end")
    suspend fun endMatch(
        @Header("Authorization") token: String,
        @Path("id") matchId: String,
        @Body request: EndMatchRequest
    ): Response<MatchResult>
    
    @GET("matches/{id}")
    suspend fun getMatchInfo(
        @Header("Authorization") token: String,
        @Path("id") matchId: String
    ): Response<MatchInfo>
    
    // ========== LEADERBOARD ==========
    
    @GET("leaderboard/global")
    suspend fun getGlobalLeaderboard(
        @Header("Authorization") token: String,
        @Query("limit") limit: Int = 100,
        @Query("offset") offset: Int = 0
    ): Response<List<PlayerStats>>
    
    @GET("leaderboard/friends")
    suspend fun getFriendsLeaderboard(
        @Header("Authorization") token: String
    ): Response<List<PlayerStats>>
}

// ========== REQUEST/RESPONSE MODELS ==========

data class LoginRequest(
    val uid: Long,
    val nickname: String,
    val version: String = "1.0.0",
    val region: String = "BR"
)

data class LoginResponse(
    val success: Boolean,
    val token: String,
    val player: Player,
    val message: String? = null
)

data class VerifyResponse(
    val valid: Boolean,
    val player: Player?
)

data class LogoutResponse(
    val success: Boolean,
    val message: String? = null
)

data class RoomInfo(
    val id: String,
    val name: String,
    val gameMode: String,
    val map: String,
    val currentPlayers: Int,
    val maxPlayers: Int,
    val status: String,
    val owner: String,
    val createdAt: Long
)

data class CreateRoomRequest(
    val name: String,
    val gameMode: String,
    val map: String,
    val maxPlayers: Int,
    val password: String? = null
)

data class JoinRoomResponse(
    val success: Boolean,
    val roomId: String,
    val message: String? = null
)

data class LeaveRoomResponse(
    val success: Boolean,
    val message: String? = null
)

data class StartMatchRequest(
    val roomId: String,
    val playerIds: List<Long>
)

data class MatchInfo(
    val id: String,
    val roomId: String,
    val map: String,
    val gameMode: String,
    val startTime: Long,
    val endTime: Long? = null,
    val players: List<Player>,
    val status: String
)

data class EndMatchRequest(
    val matchId: String,
    val winner: Long,
    val playerStats: List<PlayerMatchStats>
)

data class PlayerMatchStats(
    val uid: Long,
    val kills: Int,
    val deaths: Int,
    val headshots: Int,
    val damage: Int,
    val position: Int
)

data class MatchResult(
    val success: Boolean,
    val matchId: String,
    val winner: Long,
    val rewards: Map<String, Any>
)
