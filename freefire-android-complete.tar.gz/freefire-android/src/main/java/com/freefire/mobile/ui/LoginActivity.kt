package com.freefire.mobile.ui

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.freefire.mobile.R
import com.freefire.mobile.config.ServerConfig
import com.freefire.mobile.databinding.ActivityLoginBinding
import com.freefire.mobile.network.NetworkManager
import com.freefire.mobile.network.api.LoginRequest
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityLoginBinding
    private val TAG = "LoginActivity"
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setupUI()
    }
    
    private fun setupUI() {
        binding.apply {
            // Definir valores padrão
            uidInput.setText("123456789")
            nicknameInput.setText("Player")
            serverInput.setText(ServerConfig.SERVER_HOST)
            
            // Botão de login
            loginButton.setOnClickListener {
                performLogin()
            }
            
            // Botão de configurações
            settingsButton.setOnClickListener {
                startActivity(Intent(this@LoginActivity, SettingsActivity::class.java))
            }
        }
    }
    
    private fun performLogin() {
        val uid = binding.uidInput.text.toString().trim()
        val nickname = binding.nicknameInput.text.toString().trim()
        val serverHost = binding.serverInput.text.toString().trim()
        
        // Validar entrada
        if (uid.isEmpty() || nickname.isEmpty()) {
            Toast.makeText(this, "Preencha UID e Nickname", Toast.LENGTH_SHORT).show()
            return
        }
        
        // Mostrar loading
        showLoading(true)
        
        lifecycleScope.launch {
            try {
                val gameApi = NetworkManager.getGameApi()
                
                val loginRequest = LoginRequest(
                    uid = uid.toLong(),
                    nickname = nickname,
                    version = ServerConfig.GAME_VERSION,
                    region = ServerConfig.GAME_REGION
                )
                
                Log.d(TAG, "Enviando login para: $uid / $nickname")
                
                val response = gameApi.login(loginRequest)
                
                if (response.isSuccessful && response.body() != null) {
                    val loginResponse = response.body()!!
                    
                    if (loginResponse.success) {
                        // Salvar token
                        NetworkManager.setAuthToken(loginResponse.token)
                        
                        Log.d(TAG, "Login bem-sucedido para: $nickname")
                        Toast.makeText(this@LoginActivity, "Login bem-sucedido!", Toast.LENGTH_SHORT).show()
                        
                        // Navegar para Lobby
                        val intent = Intent(this@LoginActivity, LobbyActivity::class.java)
                        intent.putExtra("player", loginResponse.player)
                        startActivity(intent)
                        finish()
                    } else {
                        showError(loginResponse.message ?: "Erro desconhecido")
                    }
                } else {
                    showError("Erro: ${response.code()} - ${response.message()}")
                    Log.e(TAG, "Erro na resposta: ${response.errorBody()?.string()}")
                }
                
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao fazer login", e)
                showError("Erro de conexão: ${e.message}")
            } finally {
                showLoading(false)
            }
        }
    }
    
    private fun showLoading(show: Boolean) {
        binding.apply {
            if (show) {
                loginButton.isEnabled = false
                loginButton.text = "Conectando..."
                progressBar.visibility = android.view.View.VISIBLE
            } else {
                loginButton.isEnabled = true
                loginButton.text = "CONECTAR"
                progressBar.visibility = android.view.View.GONE
            }
        }
    }
    
    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        Log.e(TAG, message)
    }
}
