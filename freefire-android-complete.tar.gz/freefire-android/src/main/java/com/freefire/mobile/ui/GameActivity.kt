package com.freefire.mobile.ui

import android.os.Bundle
import android.util.Log
import android.view.MotionEvent
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.freefire.mobile.R
import com.freefire.mobile.databinding.ActivityGameBinding
import com.freefire.mobile.data.models.Player
import com.freefire.mobile.network.api.RoomInfo
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class GameActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityGameBinding
    private lateinit var currentPlayer: Player
    private lateinit var room: RoomInfo
    private val TAG = "GameActivity"
    
    // Variáveis de jogo
    private var isGameRunning = false
    private var lastUpdateTime = System.currentTimeMillis()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        binding = ActivityGameBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        // Recuperar dados do intent
        currentPlayer = intent.getSerializableExtra("player") as? Player
            ?: run {
                Toast.makeText(this, "Erro ao carregar jogador", Toast.LENGTH_SHORT).show()
                finish()
                return
            }
        
        room = intent.getSerializableExtra("room") as? RoomInfo
            ?: run {
                Toast.makeText(this, "Erro ao carregar sala", Toast.LENGTH_SHORT).show()
                finish()
                return
            }
        
        setupUI()
        startGame()
    }
    
    private fun setupUI() {
        binding.apply {
            // HUD - Saúde
            healthBar.max = 100
            healthBar.progress = currentPlayer.health
            healthText.text = "${currentPlayer.health}/100"
            
            // HUD - Armadura
            armorBar.max = 100
            armorBar.progress = currentPlayer.armor
            armorText.text = "${currentPlayer.armor}/100"
            
            // HUD - Arma
            weaponText.text = currentPlayer.weapon
            ammoText.text = "${currentPlayer.ammo}"
            
            // HUD - Posição
            positionText.text = "Pos: (${currentPlayer.position.x.toInt()}, ${currentPlayer.position.z.toInt()})"
            
            // HUD - Ping
            pingText.text = "Ping: 0ms"
            
            // HUD - FPS
            fpsText.text = "FPS: 60"
            
            // Botão de pausa
            pauseButton.setOnClickListener {
                pauseGame()
            }
            
            // Botão de mapa
            mapButton.setOnClickListener {
                showMap()
            }
            
            // Botão de inventário
            inventoryButton.setOnClickListener {
                showInventory()
            }
        }
    }
    
    private fun startGame() {
        isGameRunning = true
        Log.d(TAG, "Jogo iniciado na sala: ${room.name}")
        
        // Iniciar loop de atualização
        lifecycleScope.launch {
            while (isGameRunning) {
                updateGame()
                delay(50)  // ~20 FPS
            }
        }
    }
    
    private fun updateGame() {
        val currentTime = System.currentTimeMillis()
        val deltaTime = (currentTime - lastUpdateTime) / 1000f
        lastUpdateTime = currentTime
        
        // Atualizar HUD
        updateHUD()
        
        // Sincronizar posição com servidor
        // TODO: Implementar sincronização
    }
    
    private fun updateHUD() {
        binding.apply {
            healthBar.progress = currentPlayer.health
            healthText.text = "${currentPlayer.health}/100"
            
            armorBar.progress = currentPlayer.armor
            armorText.text = "${currentPlayer.armor}/100"
            
            positionText.text = "Pos: (${currentPlayer.position.x.toInt()}, ${currentPlayer.position.z.toInt()})"
        }
    }
    
    private fun pauseGame() {
        isGameRunning = false
        Toast.makeText(this, "Jogo pausado", Toast.LENGTH_SHORT).show()
        // TODO: Mostrar menu de pausa
    }
    
    private fun showMap() {
        Toast.makeText(this, "Mapa (em desenvolvimento)", Toast.LENGTH_SHORT).show()
    }
    
    private fun showInventory() {
        Toast.makeText(this, "Inventário (em desenvolvimento)", Toast.LENGTH_SHORT).show()
    }
    
    override fun onTouchEvent(event: MotionEvent?): Boolean {
        // TODO: Implementar controles de toque
        return super.onTouchEvent(event)
    }
    
    override fun onPause() {
        super.onPause()
        isGameRunning = false
    }
    
    override fun onResume() {
        super.onResume()
        isGameRunning = true
    }
    
    override fun onDestroy() {
        super.onDestroy()
        isGameRunning = false
    }
}
